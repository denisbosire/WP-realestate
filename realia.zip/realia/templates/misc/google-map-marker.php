<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="marker"><div class="marker-inner">
	<?php the_post_thumbnail(); ?>
</div></div>
