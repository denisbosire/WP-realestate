# realestate-plugin
WordPress Real Estate Plugin,
Slighlty modified to work with this theme http://freewprealestatetheme.com
Original plugin by these awesome guys https://github.com/PragmaticMates/realia
